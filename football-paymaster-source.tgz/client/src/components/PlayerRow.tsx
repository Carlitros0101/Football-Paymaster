import { useState, useRef } from "react";
import { Player } from "@shared/schema";
import { CheckCircle2, XCircle, Trash2, Pencil, Check, X, Phone, GripVertical, Minus, Plus, MessageCircle, StickyNote, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { EmojiPickerPopover } from "./EmojiPickerPopover";

interface PlayerRowProps {
  player: Player;
  price: number;
  onToggle: (id: string) => void;
  onCheckIn: (id: string) => void;
  onRemove: (id: string) => void;
  onUpdatePlayer: (id: string, updates: Partial<Pick<Player, 'name' | 'phone' | 'quotas' | 'notes' | 'emoji' | 'isWaitlisted'>>) => void;
  reorderMode?: boolean;
  dragHandleProps?: Record<string, unknown>;
  isWaitlist?: boolean;
  onPromote?: (id: string) => void;
  onMoveToWaitlist?: (id: string) => void;
}

const AVATAR_COLORS = [
  "bg-violet-500","bg-blue-500","bg-pink-500","bg-orange-500",
  "bg-teal-500","bg-red-500","bg-indigo-500","bg-amber-500","bg-cyan-500","bg-rose-500",
];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function getInitials(name: string): string {
  return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
}

const SWIPE_THRESHOLD = 70;

export function PlayerRow({
  player, price, onToggle, onCheckIn, onRemove, onUpdatePlayer,
  reorderMode, dragHandleProps, isWaitlist, onPromote, onMoveToWaitlist,
}: PlayerRowProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(player.name);
  const [editPhone, setEditPhone] = useState(player.phone || "");
  const [editNotes, setEditNotes] = useState(player.notes || "");

  // Swipe state
  const touchStartX = useRef<number>(0);
  const touchStartY = useRef<number>(0);
  const [swipeDelta, setSwipeDelta] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);

  const avatarColor = getAvatarColor(player.name);
  const initials = getInitials(player.name);
  const quotas = player.quotas ?? 1;

  const handleSaveEdit = () => {
    if (editName.trim()) {
      onUpdatePlayer(player.id, {
        name: editName.trim(),
        phone: editPhone.trim(),
        notes: editNotes.trim(),
      });
    }
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditName(player.name);
    setEditPhone(player.phone || "");
    setEditNotes(player.notes || "");
    setIsEditing(false);
  };

  const handleWhatsApp = () => {
    if (!player.phone) return;
    const total = quotas * price;
    const msg = `Hola ${player.name}! 👋 Te recuerdo que tienes un pago pendiente de $${total.toLocaleString()} para el partido. ¡No te olvides! ⚽`;
    window.open(`https://wa.me/${player.phone.replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const changeQuotas = (delta: number) => {
    onUpdatePlayer(player.id, { quotas: Math.max(1, quotas + delta) });
  };

  // ─── Swipe-to-pay handlers ────────────────────────────────────────
  const handleTouchStart = (e: React.TouchEvent) => {
    if (reorderMode || isEditing || isWaitlist) return;
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    setIsSwiping(false);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (reorderMode || isEditing || isWaitlist) return;
    const dx = e.touches[0].clientX - touchStartX.current;
    const dy = e.touches[0].clientY - touchStartY.current;

    if (!isSwiping && Math.abs(dy) > Math.abs(dx)) return; // vertical scroll wins
    if (Math.abs(dx) > 10) setIsSwiping(true);

    const clamped = Math.max(-SWIPE_THRESHOLD * 1.2, Math.min(SWIPE_THRESHOLD * 1.2, dx));
    setSwipeDelta(clamped);
  };

  const handleTouchEnd = () => {
    if (reorderMode || isEditing || isWaitlist) return;
    if (Math.abs(swipeDelta) >= SWIPE_THRESHOLD) {
      onToggle(player.id);
    }
    setSwipeDelta(0);
    setIsSwiping(false);
  };

  const swipeProgress = Math.abs(swipeDelta) / SWIPE_THRESHOLD;
  const swipeRight = swipeDelta > 20;
  const swipeLeft = swipeDelta < -20;

  if (isEditing) {
    return (
      <div className="flex flex-col gap-2.5 p-3 rounded-xl border-2 border-primary/40 bg-primary/5">
        <div className="flex items-center gap-2">
          <EmojiPickerPopover
            selectedEmoji={player.emoji}
            playerName={player.name}
            avatarColor={avatarColor}
            initials={initials}
            onSelect={(emoji) => onUpdatePlayer(player.id, { emoji })}
          />
          <input
            autoFocus
            value={editName}
            onChange={e => setEditName(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") handleSaveEdit(); if (e.key === "Escape") handleCancelEdit(); }}
            className="flex-1 text-sm font-semibold bg-transparent border-b-2 border-primary outline-none pb-0.5"
            placeholder="Nombre del jugador"
          />
        </div>
        <div className="flex items-center gap-2 pl-14">
          <Phone className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
          <input
            value={editPhone}
            onChange={e => setEditPhone(e.target.value)}
            className="flex-1 text-xs bg-transparent border-b border-border outline-none pb-0.5 text-muted-foreground"
            placeholder="+56 9 1234 5678"
            type="tel"
          />
        </div>
        <div className="flex items-center gap-2 pl-14">
          <StickyNote className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
          <input
            value={editNotes}
            onChange={e => setEditNotes(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") handleSaveEdit(); if (e.key === "Escape") handleCancelEdit(); }}
            className="flex-1 text-xs bg-transparent border-b border-border outline-none pb-0.5 text-muted-foreground"
            placeholder="Notas (arquero, trae pelota...)"
          />
        </div>
        <div className="flex justify-end gap-2 pt-1">
          <button onClick={handleCancelEdit} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded-lg hover:bg-muted transition-colors">
            <X className="w-3.5 h-3.5" />Cancelar
          </button>
          <button onClick={handleSaveEdit} className="flex items-center gap-1 text-xs text-white bg-primary px-2 py-1 rounded-lg hover:bg-primary/90 transition-colors">
            <Check className="w-3.5 h-3.5" />Guardar
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="group relative overflow-hidden rounded-xl"
    >
      {/* Swipe feedback backgrounds */}
      {isSwiping && (
        <>
          {swipeRight && (
            <div
              className="absolute inset-0 bg-emerald-500 rounded-xl flex items-center pl-4 gap-2 transition-opacity"
              style={{ opacity: Math.min(1, swipeProgress * 1.2) }}
            >
              <CheckCircle2 className="w-5 h-5 text-white" />
              <span className="text-white text-sm font-bold">
                {player.hasPaid ? "Desmarcar" : "¡Pagado!"}
              </span>
            </div>
          )}
          {swipeLeft && (
            <div
              className="absolute inset-0 bg-red-500 rounded-xl flex items-center justify-end pr-4 gap-2 transition-opacity"
              style={{ opacity: Math.min(1, swipeProgress * 1.2) }}
            >
              <span className="text-white text-sm font-bold">
                {player.hasPaid ? "Desmarcar" : "Pendiente"}
              </span>
              <XCircle className="w-5 h-5 text-white" />
            </div>
          )}
        </>
      )}

      {/* Main row */}
      <div
        className={cn(
          "relative flex items-center justify-between p-3 border transition-all duration-200",
          player.hasPaid
            ? "bg-emerald-50/50 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-900"
            : isWaitlist
            ? "bg-amber-50/50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-800"
            : "bg-white border-border hover:border-primary/30 dark:bg-card dark:border-border",
          "rounded-xl"
        )}
        style={{
          transform: `translateX(${swipeDelta}px)`,
          transition: isSwiping ? 'none' : 'transform 0.25s ease',
          touchAction: isWaitlist || reorderMode ? 'auto' : 'pan-y',
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="flex items-center gap-2 min-w-0">
          {reorderMode && (
            <div {...(dragHandleProps as any)} className="cursor-grab active:cursor-grabbing p-1 text-muted-foreground touch-none flex-shrink-0">
              <GripVertical className="w-4 h-4" />
            </div>
          )}

          {/* Avatar (check-in toggle) */}
          <button
            onClick={() => !isWaitlist && onCheckIn(player.id)}
            title={player.hasCheckedIn ? "Confirmado" : "Sin confirmar"}
            className={cn(
              "relative flex items-center justify-center w-9 h-9 rounded-full font-bold text-sm select-none transition-all flex-shrink-0",
              player.emoji ? "text-2xl bg-transparent" : `${avatarColor} text-white`,
              !isWaitlist && player.hasCheckedIn && "ring-2 ring-offset-1 ring-blue-400 shadow-md",
              !isWaitlist && !player.hasCheckedIn && !player.emoji && "opacity-70 hover:opacity-100",
              isWaitlist && "opacity-50 cursor-default"
            )}
          >
            {player.emoji || initials}
            {player.hasCheckedIn && !isWaitlist && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-blue-500 rounded-full border-2 border-white flex items-center justify-center">
                <svg className="w-2 h-2 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </span>
            )}
          </button>

          {/* Pay toggle (hidden for waitlist) */}
          {!isWaitlist && (
            <button
              onClick={() => onToggle(player.id)}
              data-testid={`btn-payment-${player.id}`}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full transition-all flex-shrink-0",
                player.hasPaid
                  ? "bg-emerald-500 text-white shadow-emerald-200 shadow-md"
                  : "bg-muted text-muted-foreground hover:bg-gray-200"
              )}
            >
              {player.hasPaid ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
            </button>
          )}

          {/* Info */}
          <div className="min-w-0">
            <h4 className={cn(
              "font-semibold text-sm truncate transition-colors",
              player.hasPaid ? "text-emerald-900 dark:text-emerald-50" : isWaitlist ? "text-amber-800" : "text-foreground"
            )}>
              {player.name}
            </h4>
            <div className="flex items-center gap-1.5 flex-wrap">
              <p className={cn("text-[10px] font-medium",
                isWaitlist ? "text-amber-600" : player.hasPaid ? "text-emerald-600" : "text-red-500"
              )}>
                {isWaitlist ? "EN ESPERA" : player.hasPaid ? "PAGADO" : "PENDIENTE"}
              </p>
              {player.notes && (
                <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full truncate max-w-[80px] dark:bg-amber-950/30" title={player.notes}>
                  📝 {player.notes}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {/* Waitlist: promote button */}
          {isWaitlist && onPromote && (
            <button
              onClick={() => onPromote(player.id)}
              className="flex items-center gap-1 text-xs font-semibold bg-primary text-primary-foreground px-2.5 py-1 rounded-lg hover:opacity-90 transition-opacity"
            >
              Promover
            </button>
          )}

          {/* Active: quotas stepper */}
          {!isWaitlist && player.hasPaid && (
            <div className="flex items-center gap-0.5 bg-emerald-100 rounded-lg px-1 py-0.5 dark:bg-emerald-950/40">
              <button onClick={() => changeQuotas(-1)} className="w-5 h-5 flex items-center justify-center text-emerald-700 hover:bg-emerald-200 rounded">
                <Minus className="w-3 h-3" />
              </button>
              <span className="text-xs font-bold text-emerald-700 font-mono w-5 text-center">{quotas}</span>
              <button onClick={() => changeQuotas(1)} className="w-5 h-5 flex items-center justify-center text-emerald-700 hover:bg-emerald-200 rounded">
                <Plus className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Price */}
          {!isWaitlist && (
            <span className={cn(
              "text-xs font-bold font-mono px-2 py-1 rounded-md",
              player.hasPaid
                ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300"
                : "text-muted-foreground bg-muted"
            )}>
              ${(quotas * price).toLocaleString()}
            </span>
          )}

          {/* WhatsApp reminder */}
          {!player.hasPaid && !isWaitlist && player.phone && (
            <button
              onClick={handleWhatsApp}
              className="p-1.5 text-green-600 hover:bg-green-50 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
              title="Recordatorio WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Move to waitlist */}
          {!isWaitlist && onMoveToWaitlist && (
            <button
              onClick={() => onMoveToWaitlist(player.id)}
              className="p-1.5 text-muted-foreground hover:text-amber-500 hover:bg-amber-50 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
              title="Mover a lista de espera"
            >
              <Clock className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Edit */}
          <button
            onClick={() => { setEditName(player.name); setEditPhone(player.phone || ""); setEditNotes(player.notes || ""); setIsEditing(true); }}
            className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
            title="Editar"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>

          {/* Remove */}
          <button
            onClick={() => onRemove(player.id)}
            className="p-1.5 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
            title="Eliminar"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
