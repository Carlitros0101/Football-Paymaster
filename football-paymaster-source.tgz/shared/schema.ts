import { z } from "zod";

export const playerSchema = z.object({
  id: z.string(),
  name: z.string(),
  hasPaid: z.boolean(),
  hasCheckedIn: z.boolean().default(false),
  phone: z.string().optional(),
  quotas: z.number().default(1),
  notes: z.string().optional(),
  emoji: z.string().optional(),
  isWaitlisted: z.boolean().default(false),
});

export type Player = z.infer<typeof playerSchema>;

export const expenseSchema = z.object({
  id: z.string(),
  description: z.string(),
  amount: z.number(),
});
export type Expense = z.infer<typeof expenseSchema>;

export const matchHistorySchema = z.object({
  id: z.string(),
  date: z.string(),
  fieldPrice: z.number(),
  collectedAmount: z.number(),
  playersCount: z.number(),
  playersPaidCount: z.number(),
  matchName: z.string().optional(),
});
export type MatchHistory = z.infer<typeof matchHistorySchema>;

export const matchInfoSchema = z.object({
  name: z.string().default(""),
  date: z.string().default(""),
  time: z.string().default(""),
  location: z.string().default(""),
});
export type MatchInfo = z.infer<typeof matchInfoSchema>;

export const matchSlotSchema = z.object({
  id: z.string(),
  name: z.string(),
  createdAt: z.string(),
  players: z.array(playerSchema),
  fieldPrice: z.number(),
  perPersonPrice: z.number(),
  calcMode: z.enum(['total', 'per_person']),
  matchInfo: matchInfoSchema,
  matchName: z.string(),
  expenses: z.array(expenseSchema),
});
export type MatchSlot = z.infer<typeof matchSlotSchema>;

export const appStateSchema = z.object({
  players: z.array(playerSchema),
  fieldPrice: z.number(),
  apiKey: z.string().optional(),
});
export type AppState = z.infer<typeof appStateSchema>;

export const fundTransactionSchema = z.object({
  id: z.string(),
  date: z.string(),
  description: z.string(),
  amount: z.number(),
});
export type FundTransaction = z.infer<typeof fundTransactionSchema>;

export const COLOR_THEMES = [
  { id: "emerald", label: "Esmeralda", color: "#34d399", primary: "158 64% 52%", accent: "84 81% 65%" },
  { id: "ocean",   label: "Océano",    color: "#3b82f6", primary: "217 91% 60%", accent: "190 85% 55%" },
  { id: "fire",    label: "Fuego",     color: "#f97316", primary: "25 95% 53%",  accent: "45 96% 60%" },
  { id: "purple",  label: "Morado",    color: "#a855f7", primary: "271 81% 65%", accent: "310 70% 65%" },
  { id: "slate",   label: "Pizarra",   color: "#64748b", primary: "215 25% 45%", accent: "215 20% 70%" },
] as const;
export type ThemeId = typeof COLOR_THEMES[number]["id"];

export const INITIAL_PLAYERS = [
  "Fabian", "Alexis", "Santana", "Carlito", "Sebastian",
  "Jose Luis", "Kelo", "Cristian Peluca", "Checho", "Franco",
  "Luis", "Profeta", "Cris", "Hector", "Juanito", "Williams", "Bastian"
];

export const contactPlayerSchema = z.object({
  id: z.string(),
  name: z.string(),
  phone: z.string().default(""),
  emoji: z.string().optional(),
  notes: z.string().optional(),
  createdAt: z.string(),
});
export type ContactPlayer = z.infer<typeof contactPlayerSchema>;

export const SOCCER_EMOJIS = [
  "⚽","🏅","🥇","👑","🦁","🐯","🦊","🐺","🦅","🦆",
  "🐸","🦉","🦋","🌟","⭐","🔥","💥","⚡","🌊","🌀",
  "💪","🤜","👊","✊","🤙","🖐","🏃","🚀","🎯","🎮",
  "🥷","🧠","👀","😤","😎","🤩","🔝","💯","🏆","🎖",
];
