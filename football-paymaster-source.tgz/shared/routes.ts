import { z } from 'zod';

// Minimal API contract since the app is primarily client-side with localStorage
export const api = {
  // We can keep a health check or minimal route if needed, 
  // but most logic will be client-side as requested.
  health: {
    method: 'GET' as const,
    path: '/api/health',
    responses: {
      200: z.object({ status: z.string() }),
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
